gcc auction-house.c -o auction-house
./auction-house auctions.txt 4