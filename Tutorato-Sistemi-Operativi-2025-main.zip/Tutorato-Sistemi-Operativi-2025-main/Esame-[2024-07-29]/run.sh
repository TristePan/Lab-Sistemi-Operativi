gcc -o decryptor decryptor.c -lpthread 

./decryptor keys.text ciphertext.text output.text