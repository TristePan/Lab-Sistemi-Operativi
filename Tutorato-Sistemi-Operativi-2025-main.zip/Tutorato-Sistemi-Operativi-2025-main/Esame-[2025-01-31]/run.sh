gcc main.c -o main
./main A.op1 A.op2 A.ops