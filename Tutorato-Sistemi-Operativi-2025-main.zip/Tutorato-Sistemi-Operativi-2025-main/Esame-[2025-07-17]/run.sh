gcc "main.c" -o main
./main 5 5x5-matrix-sample-a.bin 5x5-matrix-sample-b.bin