gcc main.c -o main
./main vectors-A.bin vectors-B.bin vectors-C.bin