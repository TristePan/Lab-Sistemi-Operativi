gcc -o decryptor decryptor.c
./decryptor keys.text