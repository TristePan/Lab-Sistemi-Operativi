gcc ./concat-mmap.c -Wall -O -o ./concat-mmap
./concat-mmap file1.txt file2.txt