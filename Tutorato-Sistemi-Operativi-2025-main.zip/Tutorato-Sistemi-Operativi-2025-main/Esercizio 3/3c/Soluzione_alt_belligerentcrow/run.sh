gcc ./search-mmap.c -Wall -O -o ./search-mmap
./search-mmap file1.txt t
echo ------------------------
./search-mmap file1.txt .
