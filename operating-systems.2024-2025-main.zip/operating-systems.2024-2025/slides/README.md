## Nota
Per poter scaricare automaticamente (`git pull`) i file PDF di questo repository con un client git è necessario che questo includa il supporto ai file grandi ([LFS](https://git-lfs.github.com/)). In molti casi lo si può ottenere installando il pacchetto `git-lfs` sul proprio sistema.

In alternativa è sempre possibile scaricarli manualmente impiegando l'interfaccia web.
